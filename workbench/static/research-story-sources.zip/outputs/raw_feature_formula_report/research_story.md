## 当前结论 · 训练对象改到逐笔之后，规律仍然只有部分可预测 / Current finding

**这轮已经跑完：18套相同划分的对照、逐笔学习与选模、连续变量、正则化，以及任意阶组目录验证。仍未得到“小部分样本学会、对其余样本优秀拟合”的公式。**

主样本用3,943笔训练、960笔留出：逐笔预测R²=0.077；单变量组R²=0.489；双变量组R²=0.478；任意阶组R²=0.429。这些是不同粒度的指标，不能混为一个准确率。组评分均要求至少30笔留出交易；单/双变量还要求每个分区至少两个合格组。

联合流程在18套双变量组比较中有14套误差更低、1套相同，显示进一步研究的价值；但改进幅度有限，也还没有不确定性检验来确认稳定优势。下面先讲本轮结果；此前研究完整保留在后半部分。返回[完整研究工作台](./index.html#view=overview)，或下载[方程、预测和审计来源包](./research-story-sources.zip)。

The completed comparison finds partial predictive structure, not a recovered universal law. Individual R² and group-mean R² answer different questions. Earlier analyses remain available below and in the workbench.


## A · 这次究竟改了什么 / What changed

每笔房屋的目标始终是 qᵢ=成交价ᵢ／原估值ᵢ。**用训练交易学习公式 → 对未参与训练的交易逐笔预测 → 按原条件分组 → 比较预测均值和实际均值。** 不用成交价格或价格档作为预测变量。

原方法将“所有分档条件完全相同”的记录合并，并按记录数加权，其平方误差拟合已经与逐笔训练等价。本轮真正改变的是：保留连续数值、允许正则化，以及用逐笔验证误差选模型；同一候选池也按旧的单变量组误差选一次，形成对照。

两个样本、原20/21个字段和原划分都保留。小训练量为开发池50%：主样本1,972笔、车库858笔；大训练量为3,943/1,717笔。每种训练量用三个种子，另做完整组合、空间网格和内部时间留出，总共18套。现有测试结果早已被查看过，因此这是**内部回顾验证**，不是新的盲测。

Training uses individuals; evaluation aggregates only held-out predictions and outcomes over identical group members. The old identical-profile compression was loss-equivalent. This study tests feature resolution, regularization and selection, with matched splits and no new exclusions.


## B · 现在得到的矩阵与方程 / The fitted equation

**α=(K+nλI)⁻¹(q−μ)，q̂(x)=μ+k(x,X)ᵀα。** μ为训练成交比率均值，λ是只在训练内部选择的正则化强度。保存的NPZ包含α、训练点、标准化参数及所有核参数，可以重新逐笔计算预测。

每个字段先形成相似度 bⱼ：连续变量用高斯相似度，邮编用是否同类。加性核为 Kₐ=Σⱼbⱼ/d；联合核为 Kⱼ=∏ⱼ(1+τbⱼ)/(1+τ)ᵈ。后者等于 **Σₛ τ^|S|∏ⱼ∈ₛbⱼ/(1+τ)ᵈ**，S遍历包括空集在内的全部字段子集。因此一阶直到20/21阶都在表达中，计算不需要逐项展开数百万组合。

但各阶权重受到这个核的结构约束，λ控制拟合复杂度。允许全部阶数不等于已经识别出必须存在的20阶作用。加性对照允许单变量弯曲关系；它不是只画一条直线的弱基准。

The saved kernel-ridge equation includes all interaction orders through a product expansion. It is a structured, regularized family, not an unrestricted proof of the true interaction order. The additive comparator allows nonlinear single-feature functions.


## C · 更细的信息有没有带来提升 / Did the changes help?

下表将“分档／连续”与“组误差／逐笔误差选模”分开，所有行使用同一固定留出成员。逐笔误差以百分点计；R²是1−预测平方误差／实际组均值方差，越高越好，负值意味着比直接用测试均值还差。

主样本连续逐笔选模的单变量组 r=0.739，R²=0.489，RMSE=1.39个百分点；双变量组R²=0.478。同样连续输入的加性对照分别为0.491和0.502。**对照的差异有限，不能宣称已经抓到了此前遗漏的大量高阶规律。**

Compare both calibration and correlation. A higher r alone does not establish a better equation. These pipeline comparisons also change applicable similarity functions and candidate grids; they do not isolate binning as a causal treatment.


## D · 数据加倍后是否更稳定 / Learning and transfer

下图把主样本训练量从1,972增加到3,943笔，始终预测相同960笔留出交易的双变量组均值。线为三个种子的均值，来源表保留最小值、最大值；它们共享测试集，不能当作三份独立证据。

合计18套比较中，“允许联合项并按逐笔选模”的双变量组误差低于连续加性对照的有14套，数值相同1套，其余更高。选到加性时，两者本来就是同一个模型；选到联合核也不能直接推出作用阶数。改善是否稳定，比某一套里谁略胜更重要。

Learning curves use held-out outcomes only. Seed variation is sensitivity to training and selection, not a confidence interval or independent replication.


## E · 最后仍然回到具体组 / Return to identifiable groups

任意阶目录重新检查了7,598,906个正式组。去除空测试组并按测试成员去重后，n≥30的主样本组有132,602个、车库组45,285个；它们仍然大量重叠。连续逐笔选模在这两批组上的R²分别为0.429、0.316。

下图每个点为一个主样本单变量留出组，横轴为实际成交／估值组均百分比，纵轴为预测误差（百分点）。悬停数据可查条件，下面的正式组号还可直接返回原工作台。编号相同，但工作台的完整组统计与这里的留出成员统计有不同分母。

The complete catalog is evaluated by summing individual predictions, including variation within old bins. Overlapping group counts are descriptive coverage, not independent sample sizes.


本轮按任意阶组测试误差选出的探索例子：[main-02124043](./index.html#group=main-02124043)（测试n=32，误差+11.38个百分点）；[main-04783053](./index.html#group=main-04783053)（测试n=39，误差+10.79个百分点）。悬停编号显示条件；这些组已按结果筛选，不能再视作独立确认。

These post-test residual examples are exploratory. Hover an ID for conditions; click for the original group.

## 接下来该解决什么 / Next research decision

这轮排除了一个简单解释：问题并不只是“拿组均值训练”或“没有允许高阶”。保留连续信息、逐笔选模、允许全部阶数之后，仍没有出现全面优秀的留出拟合。当前证据不支持把一个模型直接称为真解。

下一步应固定这轮保存的预测，先分清**组均值本身的抽样波动有多大，剩余误差是否还有可重复结构**。用按房屋重采样的成对误差区间比较加性与联合公式；重叠组要一起随房屋重采样，不能把数十万组当成独立样本。再通过交叉拟合检查残差与联合条件的关系，诊断应与最终确认分开。

如果残差结构能复现，再针对性检验更灵活的核相似度、正则化选择或已有字段的语义问题，并用独立时期数据确认；如果没有，继续无目的扩大阶数并不能区分噪声和缺少信息。此次尚未执行上述不确定性与残差检验。

Next, quantify paired uncertainty by resampling transactions, then test whether residual structure repeats under cross-fitting. Preserve joint group membership in resampling. This determines whether another richer equation is warranted; it has not yet been executed.


## 使用边界与核验 / Scope and verification

18套实验的划分、模型选择、保存方程逐笔重算以及组均值、r、R²均已核验。全阶扫描的交易数与原目录逐组一致，另对每个样本40个固定抽取的任意阶组直接重算成员；这40项是抽查，不声称独立逐组重算了全部预测。

单/双变量评分沿用旧规则：先要求组内最少交易数，再保留至少两个合格组的分区，分区等权、分区内组等权。全阶目录按独特测试成员组等权。两者不是同一指标。原楼层字段仍是语义有疑点的代理（主样本最大值52），未擅自裁剪为“正常楼层”。房屋属性快照、当前坐标代理、历史评分及估值年份口径等限制仍在；可得性与价格相关的样本结论不得推广到整体，更不能据预测相关性宣称因果来源。

Independent validation covers all stored predictions and supported group scores. Historical snapshots, feature semantics, selected-sample scope and previously inspected holdouts limit interpretation. No claim of causal identification or external validation is made.


## 前一阶段研究与证据 / Earlier research retained

以下是v1.4阶段的研究过程、无正则公式验证和已知答案实验。数字与原分析保持一致；其中“当前”“下一步”措辞以本页上方本轮结论为准。此前完整报告和方程证据也保留在下载包的previous_formula_evidence.zip中。

The following material preserves the preceding stage. Its historical status language is superseded by the new experiment above; its measured results are unchanged.


## 01 · 研究已经从“哪里估偏了”走到“能否推导出规律” / The question we are pursuing

现实出发点是：住宅的原估值与实际成交之间，是否存在有规律的组间偏差？我们逐步把单一价格档扩展为房屋、位置、学校、警情与岗位环境等条件的任意组合，寻找哪些组合的平均比例最高或最低。

随后出现一个方法问题：大量组彼此重叠，单项效应加起来未必等于联合结果。**能否把这种复杂结构组织为一个方程，并检验产生方程的方法是否可靠？** 这使研究形成一条连续主线：

**定位组合差异 → 推导统一表达 → 验证推导方法 → 提炼稳定规律 → 评价解释与应用价值。**

最初的公平性问题提供现实意义；公式及其验证是当前研究核心。最终可能帮助发现需要修正的估价环节，但现阶段尚未证明优于政府系统，也没有建立具体因果来源。

The practical question concerns assessment gaps. The methodological question is whether a unified formula can recover repeatable structure across combinations. Application follows evidence of generalization; it is not implied by a matrix representation alone.


## 02 · 研究单位一直是条件组 / Our unit is a condition group

每笔交易的比例为 **q=成交价／原估值**。组指标是该组每笔q的算术平均：100%表示均比率与一致基准相同，超过100%表示成交相对估值更高。我们排序和验证的重点是组均值。

2017清洗基准有8,595笔；补充条件齐备的主组合样本有4,903笔、20个字段，正车库样本有2,148笔、21个字段。两个样本有重叠。资料可得性与价格有关，所以组合结论限相应可用交易，不自动代表全部交易或全市住宅。

本轮组预测按同一单位评价：对未参与推导的成员计算公式预测，再汇总为各组平均，与该组的实际平均比较。单套房预测仅作辅助检查。

We study arithmetic means of transaction-level sale/assessment ratios. The enriched cohorts are selected and overlap. Formula validation must compare predicted and observed means for the same held-out group members.


## 03 · 从发现与表达，推进到方法实测 / What we have completed

我们已经完成数据整理、任意组合发现、条件比较和数学表达。本轮再完成30项真实数据实验与180项已知答案设置，将“方程如何从部分资料推导出来”整个过程放到留出数据上检查。下表标明各项工作的证据角色。

The study now includes actual validation of the derivation. Discovery, representation, predictive tests and mechanism interpretation remain distinct stages.


## 04 · 部分组差异超出共同水平偏移 / Differences extend beyond one common offset

主样本共有5,550,736个不同成员条件组，整体均比率约108.40%。在统一除去这一水平偏移后，至少100笔的组仍有46,350个偏离±5%；至少300笔有931个，至少500笔有51个，至少1,000笔则为0个。

下图显示不同支持门槛下，这些组占合格组的比例。它说明差异并非只发生在个位数小组中，同时也显示大支持规模下差异收窄。**这些组高度重叠，不能把组数量当作独立发现数量。** 排序提供候选，重复出现的规律仍须另行验证。

Some group differences remain after a common level adjustment. Their prevalence falls as the minimum group size increases. Counts refer to overlapping groups, not independent discoveries.

[查看原始高低组、条件和分布 / Inspect extremes and conditions](./index.html#view=extremes)


## 05 · 联合条件值得研究，但现有对照尚未给出原因 / Joint conditions matter; mechanism remains open

我们已经做过条件放宽、共同支持标准化和四格非加性比较。一个可复查的例子是 [M025的完整条件](./index.html#view=controls&group=main-03600322 "房龄 / Age = ≥60年 / years；原表楼层代理 / Story proxy = 2–<3层 / stories；距市政厅 / City Hall distance = ≥10 km；6年级学校档位 / Grade-6 school tier = 关注 / Watch；9年级学校档位 / Grade-9 school tier = 干预 / Intervene；住宅入室 / Burglary · 365d / 500m = >0–≤11")：

**房龄 / Age = ≥60年 / years；原表楼层代理 / Story proxy = 2–<3层 / stories；距市政厅 / City Hall distance = ≥10 km；6年级学校档位 / Grade-6 school tier = 关注 / Watch；9年级学校档位 / Grade-9 school tier = 干预 / Intervene；住宅入室 / Burglary · 365d / 500m = >0–≤11。**

放宽其中的住宅入室记录条件后，原325笔与新增562笔的组均差为8.14个百分点。进入共同支持后只保留117与280笔；联合标准化后仍差6.82个百分点。下图把支持改变与标准化后的结果并列，说明已测条件的组成没有消除这个比较中的差异。

它没有隔离出治安的因果作用。全1,920项标准化比较中，653项有共同支持，1,267项无法计算；这些未成功的比较也构成研究结论。现有控制分析的价值是缩小问题范围，并识别哪些解释还缺证据。

The M025 contrast remains on a smaller common-support sample after standardization. This is a conditional association. Many planned comparisons lack common support, so the existing controls do not settle the causal mechanism.


## 06 · 先分清表达与预测，再读实测结果 / Representation and prediction have separate tests

相同完整条件组合的交易会同时进入任何相关条件组。因此，每种完整状态只需保留**交易数n和比率和s**，就能重建全部组均值。主样本的5,550,736个组由3,310个有数据的完整状态支撑；这使庞大目录可以统一计算。

我们又构建了逐阶条件核，把状态均值写成 **m̂(x)=μ+ΣαᵤKₖ(x,xᵤ)**。条件核把单项、两项及更高阶组合放在同一套函数空间中；参数由数据求出。这套核与显式条件空间的等价性、数值计算和现有组还原已经核验。

下图展示允许阶数增加时，能表达的数值维度占已观察状态数的比例。两样本在三阶达到100%，意味着当前支持上可以精确插值。**这不是留出准确率，也不证明现实关系最高只有三阶。** 主样本仍保留3,310个系数，正车库1,449个；低阶表达与少参数规律还不是同一项成果。

The count/sum representation exactly recovers observed group means. The kernel gives a nested all-order function space. Full observed rank at degree three establishes interpolation on current support; it does not establish a small-parameter law or predictive accuracy.

[查看原方程、矩阵与还原误差 / Inspect the original algebra](./index.html#view=algebra)


## 07 · 评分对象是重新推导的方程 / What exactly was tested

每次只在训练交易中重新构造剖面、计算均值并求系数；测试成员只接受预测。**主指标比较同一组测试成员的实际q平均与预测平均。** 单字段类别构成互斥分区；每个有效分区权重相同，区内合格组等权。主样本74组、正车库54组，每组测试n≥30。不同分区会重复使用交易，这些组不是独立重复样本。

下表比较预先固定的训练均值、一阶、原三阶，以及只用训练内部数据从全部0..20/21阶中选出的方程。显示第一预设种子；三种子完整结果与选阶敏感性在后文。r描述共同变化，预测R²按平方误差定义，可以为负；常数预测的r为空。百分点误差给出实际偏离量。

Each equation is derived using training responses only. Scores compare predicted and observed means on identical held-out members. These are retrospective internal tests with an already explored feature dictionary, not untouched external confirmation or pre-sale forecasting.


## 08 · 训练量增加并未消除选阶波动 / Learning and degree selection

以下曲线在同一批测试成员上，使用10%、25%、50%、100%的可用训练交易重新推导。每点是三个预设种子的误差中位数；完整最小值/最大值保留在源表中。种子改变训练抽样和内部选阶，不改变外层测试集；这不是三个独立外部重复。

主样本使用全部3,943笔时，三个内部选阶结果为8、17、1，对应测试R²约0.187、0.162、0.508；正车库为21、0、21。选择过程会波动，因此不能只展示表现最好的一次。固定三阶的训练剖面误差接近0，留出误差仍高，这与单交易剖面多、插值对噪声敏感相容，尚不能归因于某一个具体原因。

The learning curves reveal instability in selected complexity. Full training interpolation is compatible with substantial held-out error. The displayed medians are descriptive; all seed outcomes remain available.


正车库样本在小训练量下更不稳定，增加训练资料后也没有显示稳定的联合阶数优势。它是主样本的选择子集；两条曲线的差别不能解释为车库变量的效果。

The positive-garage cohort is smaller and selected. Its learning pattern is not an isolated estimate of the garage feature's value.


## 09 · 任意阶组目录也接受了留出检查 / The complete group directory

我们重新计算了全部7,598,906个已有条件组的测试成员，而不只检验单字段组。主样本有482,261个原组没有测试成员；其余组按测试成员精确去重后，得到831,185个不同测试成员组，正车库为264,935个。以下表格按测试支持n≥30/100分别列出；去重仍不消除组间重叠。

主样本n≥30的132,602组，一阶r约0.750、R²约0.376、RMSE约2.48个百分点；原三阶R²约−0.261。可见一阶结构的信号不只出现在单字段评分中，但任意组合上的误差更大，仍留下需要研究的联合差异。不要把这与前表74组的R²混成同一口径。

All existing groups were evaluated on their held-out members, with exact membership duplicates removed for this table. The broader group family has different dispersion and weighting from the primary partitions. Neither millions of group rows nor deduplication creates independent evidence.


## 10 · 新组合、地区与时间给出不同边界 / Transfer within the current data

新增三种完整重训：全部剖面分组留出、1公里网格分组留出、成交日期最后约20%留出。同一天不跨时间边界；内部选阶也采用对应类型的划分。网格留出没有空间缓冲，时间测试仍在2017年内。

下图只展示训练内选阶规则的结果，完整基准对照保留在来源数据。主样本在三种划分上的R²分别约0.412、0.183、0.298；正车库更弱。原无正则三阶在两样本三种划分中的R²均为负。这里已经有可重复结构的线索，但并没有得到一套在所有范围都可靠的联合公式。

Profile, grid and chronological holdouts answer different transfer questions. Main-cohort selected equations show positive results in these specified tests, but performance and selected degree depend on scope. This is within-dataset transfer, not new-year or new-city confirmation.


## 11 · 已知答案解释了为什么“精确”仍可能不准 / What known-answer tests establish

我们构造了8个二值字段的256个状态，分别设定单项、两项、四项、八项关系与纯噪声，共180个阶数/支持/噪声设置。这里按完整状态评分，每状态有4个独立测试重复；不套用住房n≥30门槛，也不以单字段均值判断高阶奇偶关系。

下图是无噪声四阶函数。使用205个状态训练，在51个未见状态上，四阶真值误差约4.3×10⁻¹³个百分点，三阶约10.66、八阶约4.51。四阶空间在这批训练支持上足以识别该函数；更宽的空间仍能精确拟合训练值，却选择了不同延拓。

加入标准差4个百分点的独立噪声后，四阶未见状态真值RMSE约4.04个百分点；完整支持下约1.56。八阶奇偶关系在缺角支持上也未恢复。**数学等价性、可辨识性和噪声稳定性是三项不同的检验。** 这些是受控示例，不是现实房价函数的证明。

Controlled tests verify equivalence and identifiable recovery, while exposing extrapolation and noise limits. Higher degrees are not universally better. Error against the known function and error against noisy test means are saved separately.


## 12 · 将预测误差重新连接到具体条件 / Residuals remain inspectable

下图每点为主样本一个预设单字段测试组，显示第一预设种子的选阶公式。横轴是实际组均成交／估值百分比，纵轴是预测减实际的百分点误差；0线表示一致。每个点的条件名称与支持规模保留在图表数据中，因此数字能回到具体组别。

这些残差用于下一步诊断，不能把按测试误差挑出的组再当作未筛选的确认结果。来源包还保留任意阶组的最大残差及正式组号，可返回原工作台查看完整条件。

Residuals identify where the selected equation misses the specified held-out group means. Post-test extreme residuals are exploratory diagnostics, not independently confirmed mechanisms.


按第一预设选阶模型的测试误差选出的核查例子：[main-02124043](./index.html#group=main-02124043)（测试n=32，预测误差+13.07个百分点）；[main-04783053](./index.html#group=main-04783053)（测试n=39，预测误差+12.37个百分点）。悬停编号可见原条件，点击返回完整组；工作台显示的是原全样本统计，本页误差使用留出成员。

These examples are selected after examining test residuals. IDs resolve to the original full-cohort groups; the validation statistics use held-out members.