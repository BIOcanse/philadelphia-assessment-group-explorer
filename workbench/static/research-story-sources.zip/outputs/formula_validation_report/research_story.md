## 当前结论 / Research summary

**我们现在已有本公式的真实留出验证：现有条件包含一定可预测的组间结构，但原来的无正则三阶精确表达没有表现出稳定的预测优势。**

主样本以3,943笔训练、960笔留出，在预设的74个单字段条件组上，固定一阶公式 **r=0.774、预测R²=0.508、RMSE=1.37个百分点**；原三阶R²=-0.425。这些分数来自我们自己的核公式和相同测试成员，不是其他模型或金额相关性。

已知答案实验验证了核与显式方程的一致性，也显示：当支持允许识别时，四阶关系能被恢复；缺少组合状态或存在噪声时，精确拟合并不保证准确延拓。**下一步重点是检验怎样稳定地保留联合规律，而不是继续追求训练内零误差。**

The derivation now has measured hold-out results. Additive structure predicts some group differences, while the original unregularized degree-three interpolant lacks stable predictive advantage. Controlled tests support the mathematics and expose support/noise limitations.

[完整工作台 / Full workbench](./index.html#view=overview) · [本轮数据、方程与验证记录 / Evidence and equations](./research-story-sources.zip)


## 01 · 研究已经从“哪里估偏了”走到“能否推导出规律” / The question we are pursuing

现实出发点是：住宅的原估值与实际成交之间，是否存在有规律的组间偏差？我们逐步把单一价格档扩展为房屋、位置、学校、警情与岗位环境等条件的任意组合，寻找哪些组合的平均比例最高或最低。

随后出现一个方法问题：大量组彼此重叠，单项效应加起来未必等于联合结果。**能否把这种复杂结构组织为一个方程，并检验产生方程的方法是否可靠？** 这使研究形成一条连续主线：

**定位组合差异 → 推导统一表达 → 验证推导方法 → 提炼稳定规律 → 评价解释与应用价值。**

最初的公平性问题提供现实意义；公式及其验证是当前研究核心。最终可能帮助发现需要修正的估价环节，但现阶段尚未证明优于政府系统，也没有建立具体因果来源。

The practical question concerns assessment gaps. The methodological question is whether a unified formula can recover repeatable structure across combinations. Application follows evidence of generalization; it is not implied by a matrix representation alone.


## 02 · 研究单位一直是条件组 / Our unit is a condition group

每笔交易的比例为 **q=成交价／原估值**。组指标是该组每笔q的算术平均：100%表示均比率与一致基准相同，超过100%表示成交相对估值更高。我们排序和验证的重点是组均值。

2017清洗基准有8,595笔；补充条件齐备的主组合样本有4,903笔、20个字段，正车库样本有2,148笔、21个字段。两个样本有重叠。资料可得性与价格有关，所以组合结论限相应可用交易，不自动代表全部交易或全市住宅。

本轮组预测按同一单位评价：对未参与推导的成员计算公式预测，再汇总为各组平均，与该组的实际平均比较。单套房预测仅作辅助检查。

We study arithmetic means of transaction-level sale/assessment ratios. The enriched cohorts are selected and overlap. Formula validation must compare predicted and observed means for the same held-out group members.


## 03 · 从发现与表达，推进到方法实测 / What we have completed

我们已经完成数据整理、任意组合发现、条件比较和数学表达。本轮再完成30项真实数据实验与180项已知答案设置，将“方程如何从部分资料推导出来”整个过程放到留出数据上检查。下表标明各项工作的证据角色。

The study now includes actual validation of the derivation. Discovery, representation, predictive tests and mechanism interpretation remain distinct stages.


## 04 · 部分组差异超出共同水平偏移 / Differences extend beyond one common offset

主样本共有5,550,736个不同成员条件组，整体均比率约108.40%。在统一除去这一水平偏移后，至少100笔的组仍有46,350个偏离±5%；至少300笔有931个，至少500笔有51个，至少1,000笔则为0个。

下图显示不同支持门槛下，这些组占合格组的比例。它说明差异并非只发生在个位数小组中，同时也显示大支持规模下差异收窄。**这些组高度重叠，不能把组数量当作独立发现数量。** 排序提供候选，重复出现的规律仍须另行验证。

Some group differences remain after a common level adjustment. Their prevalence falls as the minimum group size increases. Counts refer to overlapping groups, not independent discoveries.

[查看原始高低组、条件和分布 / Inspect extremes and conditions](./index.html#view=extremes)


## 05 · 联合条件值得研究，但现有对照尚未给出原因 / Joint conditions matter; mechanism remains open

我们已经做过条件放宽、共同支持标准化和四格非加性比较。一个可复查的例子是 [M025的完整条件](./index.html#view=controls&group=main-03600322 "房龄 / Age = ≥60年 / years；原表楼层代理 / Story proxy = 2–<3层 / stories；距市政厅 / City Hall distance = ≥10 km；6年级学校档位 / Grade-6 school tier = 关注 / Watch；9年级学校档位 / Grade-9 school tier = 干预 / Intervene；住宅入室 / Burglary · 365d / 500m = >0–≤11")：

**房龄 / Age = ≥60年 / years；原表楼层代理 / Story proxy = 2–<3层 / stories；距市政厅 / City Hall distance = ≥10 km；6年级学校档位 / Grade-6 school tier = 关注 / Watch；9年级学校档位 / Grade-9 school tier = 干预 / Intervene；住宅入室 / Burglary · 365d / 500m = >0–≤11。**

放宽其中的住宅入室记录条件后，原325笔与新增562笔的组均差为8.14个百分点。进入共同支持后只保留117与280笔；联合标准化后仍差6.82个百分点。下图把支持改变与标准化后的结果并列，说明已测条件的组成没有消除这个比较中的差异。

它没有隔离出治安的因果作用。全1,920项标准化比较中，653项有共同支持，1,267项无法计算；这些未成功的比较也构成研究结论。现有控制分析的价值是缩小问题范围，并识别哪些解释还缺证据。

The M025 contrast remains on a smaller common-support sample after standardization. This is a conditional association. Many planned comparisons lack common support, so the existing controls do not settle the causal mechanism.


## 06 · 先分清表达与预测，再读实测结果 / Representation and prediction have separate tests

相同完整条件组合的交易会同时进入任何相关条件组。因此，每种完整状态只需保留**交易数n和比率和s**，就能重建全部组均值。主样本的5,550,736个组由3,310个有数据的完整状态支撑；这使庞大目录可以统一计算。

我们又构建了逐阶条件核，把状态均值写成 **m̂(x)=μ+ΣαᵤKₖ(x,xᵤ)**。条件核把单项、两项及更高阶组合放在同一套函数空间中；参数由数据求出。这套核与显式条件空间的等价性、数值计算和现有组还原已经核验。

下图展示允许阶数增加时，能表达的数值维度占已观察状态数的比例。两样本在三阶达到100%，意味着当前支持上可以精确插值。**这不是留出准确率，也不证明现实关系最高只有三阶。** 主样本仍保留3,310个系数，正车库1,449个；低阶表达与少参数规律还不是同一项成果。

The count/sum representation exactly recovers observed group means. The kernel gives a nested all-order function space. Full observed rank at degree three establishes interpolation on current support; it does not establish a small-parameter law or predictive accuracy.

[查看原方程、矩阵与还原误差 / Inspect the original algebra](./index.html#view=algebra)


## 07 · 评分对象是重新推导的方程 / What exactly was tested

每次只在训练交易中重新构造剖面、计算均值并求系数；测试成员只接受预测。**主指标比较同一组测试成员的实际q平均与预测平均。** 单字段类别构成互斥分区；每个有效分区权重相同，区内合格组等权。主样本74组、正车库54组，每组测试n≥30。不同分区会重复使用交易，这些组不是独立重复样本。

下表比较预先固定的训练均值、一阶、原三阶，以及只用训练内部数据从全部0..20/21阶中选出的方程。显示第一预设种子；三种子完整结果与选阶敏感性在后文。r描述共同变化，预测R²按平方误差定义，可以为负；常数预测的r为空。百分点误差给出实际偏离量。

Each equation is derived using training responses only. Scores compare predicted and observed means on identical held-out members. These are retrospective internal tests with an already explored feature dictionary, not untouched external confirmation or pre-sale forecasting.


## 08 · 训练量增加并未消除选阶波动 / Learning and degree selection

以下曲线在同一批测试成员上，使用10%、25%、50%、100%的可用训练交易重新推导。每点是三个预设种子的误差中位数；完整最小值/最大值保留在源表中。种子改变训练抽样和内部选阶，不改变外层测试集；这不是三个独立外部重复。

主样本使用全部3,943笔时，三个内部选阶结果为8、17、1，对应测试R²约0.187、0.162、0.508；正车库为21、0、21。选择过程会波动，因此不能只展示表现最好的一次。固定三阶的训练剖面误差接近0，留出误差仍高，这与单交易剖面多、插值对噪声敏感相容，尚不能归因于某一个具体原因。

The learning curves reveal instability in selected complexity. Full training interpolation is compatible with substantial held-out error. The displayed medians are descriptive; all seed outcomes remain available.


正车库样本在小训练量下更不稳定，增加训练资料后也没有显示稳定的联合阶数优势。它是主样本的选择子集；两条曲线的差别不能解释为车库变量的效果。

The positive-garage cohort is smaller and selected. Its learning pattern is not an isolated estimate of the garage feature's value.


## 09 · 任意阶组目录也接受了留出检查 / The complete group directory

我们重新计算了全部7,598,906个已有条件组的测试成员，而不只检验单字段组。主样本有482,261个原组没有测试成员；其余组按测试成员精确去重后，得到831,185个不同测试成员组，正车库为264,935个。以下表格按测试支持n≥30/100分别列出；去重仍不消除组间重叠。

主样本n≥30的132,602组，一阶r约0.750、R²约0.376、RMSE约2.48个百分点；原三阶R²约−0.261。可见一阶结构的信号不只出现在单字段评分中，但任意组合上的误差更大，仍留下需要研究的联合差异。不要把这与前表74组的R²混成同一口径。

All existing groups were evaluated on their held-out members, with exact membership duplicates removed for this table. The broader group family has different dispersion and weighting from the primary partitions. Neither millions of group rows nor deduplication creates independent evidence.


## 10 · 新组合、地区与时间给出不同边界 / Transfer within the current data

新增三种完整重训：全部剖面分组留出、1公里网格分组留出、成交日期最后约20%留出。同一天不跨时间边界；内部选阶也采用对应类型的划分。网格留出没有空间缓冲，时间测试仍在2017年内。

下图只展示训练内选阶规则的结果，完整基准对照保留在来源数据。主样本在三种划分上的R²分别约0.412、0.183、0.298；正车库更弱。原无正则三阶在两样本三种划分中的R²均为负。这里已经有可重复结构的线索，但并没有得到一套在所有范围都可靠的联合公式。

Profile, grid and chronological holdouts answer different transfer questions. Main-cohort selected equations show positive results in these specified tests, but performance and selected degree depend on scope. This is within-dataset transfer, not new-year or new-city confirmation.


## 11 · 已知答案解释了为什么“精确”仍可能不准 / What known-answer tests establish

我们构造了8个二值字段的256个状态，分别设定单项、两项、四项、八项关系与纯噪声，共180个阶数/支持/噪声设置。这里按完整状态评分，每状态有4个独立测试重复；不套用住房n≥30门槛，也不以单字段均值判断高阶奇偶关系。

下图是无噪声四阶函数。使用205个状态训练，在51个未见状态上，四阶真值误差约4.3×10⁻¹³个百分点，三阶约10.66、八阶约4.51。四阶空间在这批训练支持上足以识别该函数；更宽的空间仍能精确拟合训练值，却选择了不同延拓。

加入标准差4个百分点的独立噪声后，四阶未见状态真值RMSE约4.04个百分点；完整支持下约1.56。八阶奇偶关系在缺角支持上也未恢复。**数学等价性、可辨识性和噪声稳定性是三项不同的检验。** 这些是受控示例，不是现实房价函数的证明。

Controlled tests verify equivalence and identifiable recovery, while exposing extrapolation and noise limits. Higher degrees are not universally better. Error against the known function and error against noisy test means are saved separately.


## 12 · 将预测误差重新连接到具体条件 / Residuals remain inspectable

下图每点为主样本一个预设单字段测试组，显示第一预设种子的选阶公式。横轴是实际组均成交／估值百分比，纵轴是预测减实际的百分点误差；0线表示一致。每个点的条件名称与支持规模保留在图表数据中，因此数字能回到具体组别。

这些残差用于下一步诊断，不能把按测试误差挑出的组再当作未筛选的确认结果。来源包还保留任意阶组的最大残差及正式组号，可返回原工作台查看完整条件。

Residuals identify where the selected equation misses the specified held-out group means. Post-test extreme residuals are exploratory diagnostics, not independently confirmed mechanisms.


按第一预设选阶模型的测试误差选出的核查例子：[main-02124043](./index.html#group=main-02124043)（测试n=32，预测误差+13.07个百分点）；[main-04783053](./index.html#group=main-04783053)（测试n=39，预测误差+12.37个百分点）。悬停编号可见原条件，点击返回完整组；工作台显示的是原全样本统计，本页误差使用留出成员。

These examples are selected after examining test residuals. IDs resolve to the original full-cohort groups; the validation statistics use held-out members.

## 下一步 · 检验联合项能否带来稳定增益 / The next research decision

当前证据支持继续研究，但研究目标应从“精确保存当前数据”转向“稳定学习组合规律”。下一步保留同一条件核和任意阶能力，比较明确的谱收缩/正则化与更稳定的训练内选阶，检验联合项相对单项是否带来可重复增益。它们尚未在本轮执行，不能提前写成提升。

之后才依据稳定残差决定具体补充哪些现实资料，并评价校准后的估价差距。真正确认泛化需要兼容新时期数据；现有选择样本和时间信息的限制仍然有效。预测成功也不自动给出政府估价偏差的因果来源。

Next, test whether controlled shrinkage and more stable training-only selection preserve useful joint structure beyond the additive baseline. Mechanism investigation and valuation improvement require their own evidence; external confirmation needs aligned new data.


## 阶段结论 / Where the study now stands

**已完成：** 组合差异发现、统一数学表达，以及本推导方法的实际留出和已知答案检验。主样本存在可预测的组间结构；原无正则三阶的精确还原没有转化为稳定的预测优势。

**仍未解决：** 怎样稳定地提取联合项、怎样进一步压缩为可读规律，以及这些规律对应哪些现实原因。当前结果既没有否定联合偏差存在，也没有证明复杂公式越高阶越有效。

The study has advanced from representation to empirical validation. There is predictive group structure, and there is a concrete stability problem to solve before treating a complex expression as a reusable valuation-bias model.
