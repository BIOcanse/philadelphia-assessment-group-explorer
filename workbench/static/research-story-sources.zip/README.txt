Evidence and reproducible research sources for the main narrative.
The builders require the research workspace and named original source files.
Formula holdout validation status: executed.
The frozen protocol records its pre-execution state; current results and validation receipts supersede that status.
Case predictions, splits and fitted equations are included when an evidence directory is supplied; repeated per-case group tables and large binary catalogs are not duplicated.
