Derived evidence for the research story. Original study data are not duplicated here.
The Python builder requires the research workspace and local scientific dependencies.
The base-R script requires only R and the named original CSVs; it was supplied but not executed.
The initial private handoff document is identified by hash only and is not distributed.
