Existing evidence and research plan for the main narrative. Original study data are not duplicated here.
The builder requires the research workspace and named source files.
Held-out validation of the algebraic derivation has not been executed; no score is claimed.
